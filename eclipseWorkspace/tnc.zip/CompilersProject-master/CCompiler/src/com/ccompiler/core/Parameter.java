package com.ccompiler.core;

public interface Parameter {
	
	public Type getType();

}
