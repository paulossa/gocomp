# CompilersProject
Project of the Compilers course using JFlex, CUP and a C grammar.
