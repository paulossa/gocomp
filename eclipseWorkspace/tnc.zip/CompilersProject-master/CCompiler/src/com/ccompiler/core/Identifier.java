package com.ccompiler.core;

public interface Identifier {
	
	public String toString();
}
