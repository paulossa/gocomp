package com.ccompiler.core;

public class Default extends Case{

	public Default(Expression expression, Register r) {
		super(expression, r);
	}

}
